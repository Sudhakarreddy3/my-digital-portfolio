const skills = ["Python", "JavaScript", "Django", "React", "AWS", "GCP", "DaVinci Resolve"];
export default function Skills() {
  return (
    <section className="bg-gray-200 p-6">
      <h2 className="text-2xl font-bold text-center mb-4">🛠 Skills</h2>
      <div className="flex flex-wrap justify-center gap-4">
        {skills.map(skill => (
          <span key={skill} className="bg-white px-4 py-2 rounded shadow">{skill}</span>
        ))}
      </div>
    </section>
  );
}
