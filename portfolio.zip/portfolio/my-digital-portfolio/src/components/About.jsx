export default function About() {
    return (
      <section className="p-6 text-center">
        <h2 className="text-3xl font-bold mb-2">👋 Hello, I'm Sudhakar!</h2>
        <p className="max-w-xl mx-auto text-lg">
          I'm an AI Developer & YouTuber blending code and creativity to build awesome digital experiences.
        </p>
      </section>
    );
  }
  