const videos = [
    { title: "Install VS Code", link: "#" },
    { title: "Deploy Django App", link: "#" },
    { title: "Object Detection with GCP", link: "#" },
  ];
  
  export default function YouTubeSection() {
    return (
      <section className="bg-red-50 p-6">
        <h2 className="text-2xl font-bold text-center mb-4">🎥 Latest YouTube Videos</h2>
        <ul className="list-disc list-inside max-w-lg mx-auto">
          {videos.map((vid, i) => (
            <li key={i}>
              <a href={vid.link} className="text-blue-600 hover:underline">{vid.title}</a>
            </li>
          ))}
        </ul>
      </section>
    );
  }
  