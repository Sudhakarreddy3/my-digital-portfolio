export default function Header() {
    return (
      <header className="bg-white shadow p-4 sticky top-0 z-50">
        <h1 className="text-2xl font-bold text-center">Sudhakar Reddy's Digital Portfolio</h1>
      </header>
    );
  }
  