const projects = [
    { title: "Food Delivery App", desc: "Built with Python, deployed on AWS." },
    { title: "Object Detection with GCP", desc: "Vision AI powered recognition system." },
    { title: "Dynamic YouTube Clone", desc: "Django + React based custom video platform." },
  ];
  
  export default function Projects() {
    return (
      <section className="p-6">
        <h2 className="text-2xl font-bold text-center mb-4">💼 Projects</h2>
        <div className="grid md:grid-cols-3 gap-4">
          {projects.map((project, i) => (
            <div key={i} className="bg-white p-4 rounded-lg shadow">
              <h3 className="font-semibold">{project.title}</h3>
              <p>{project.desc}</p>
            </div>
          ))}
        </div>
      </section>
    );
  }
  