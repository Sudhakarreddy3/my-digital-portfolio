export default function Contact() {
    return (
      <section className="p-6 text-center">
        <h2 className="text-2xl font-bold mb-2">📬 Let's Connect</h2>
        <p>Email: <a href="https://sudhakarraddy534@gmail.com" className="text-blue-600">sudhakarraddy534@gmail.com</a></p>
        <p>GitHub: <a href="https://github.com/Sudhakarreddy3" className="text-blue-600">github.com/Sudhakarreddy3</a></p>
        <p>YouTube: <a href="https://youtube.com/@sudhakarreddy-6727" className="text-blue-600">youtube.com/Programming Steps</a></p>
      </section>
    );
  }
  