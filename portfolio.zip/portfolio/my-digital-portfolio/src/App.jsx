import Header from './components/Header';
import About from './components/About';
import Skills from './components/Skills';
import Projects from './components/Projects';
import YouTubeSection from './components/YouTubeSection';
import Contact from './components/Contact';
import Footer from './components/Footer';

function App() {
  return (
    <div className="bg-gray-100 text-gray-900 font-sans">
      <Header />
      <About />
      <Skills />
      <Projects />
      <YouTubeSection />
      <Contact />
      <Footer />
    </div>
  );
}

export default App;
